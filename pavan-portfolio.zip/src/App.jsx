import React from "react";
import Portfolio from "./Portfolio";
export default function App(){ return <Portfolio/> }