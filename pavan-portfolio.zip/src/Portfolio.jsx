import React from "react";

export default function Portfolio(){
  return (
    <div style={{color:"white",padding:"20px",background:"#081025",minHeight:"100vh"}}>
      <h1>Baitapalli Pavan Kumar</h1>
      <p>AI/ML • Automation • Full-stack Developer</p>
      <p>This is your portfolio home page.</p>
    </div>
  );
}